module.exports = {
  name: 'help',
  async execute(message) {
    message.channel.send('**Commands:**\n`!dmall <message>` - DM all members\n`!help` - Show this menu');
  }
};
