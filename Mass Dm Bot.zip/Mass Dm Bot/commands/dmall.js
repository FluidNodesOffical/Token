const config = require('../config.json');

module.exports = {
  name: 'dmall',
  async execute(message, args, client) {
    if (message.author.id !== config.ownerID) {
      return message.reply('You are not allowed to use this command.');
    }

    const text = args.join(' ');
    if (!text) return message.reply('You must include a message to send.');

    let count = 0;
    const members = await message.guild.members.fetch();

    for (const member of members.values()) {
      if (
        !member.user.bot &&
        member.id !== client.user.id &&
        member.id !== message.author.id
      ) {
        try {
          await member.send(text);
          count++;
          await new Promise(resolve => setTimeout(resolve, 2000)); // 2s delay
        } catch (err) {
          console.log(`Failed to DM ${member.user.tag}`);
        }
      }
    }

    message.channel.send(`✅ DMed ${count} users.`);
  }
};
