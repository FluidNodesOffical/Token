{
  "token": "YOUR_BOT_TOKEN",
  "prefix": "!",
  "ownerID": "YOUR_DISCORD_ID"
}